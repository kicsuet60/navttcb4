<?php
    // $x = 40; // x smaller then 40, Print > X is smaller
    // if($x < 40){
    //     echo "X is smaller";
    // } else {
    //     echo "X is Greater or Equal";
    // }

    /////////////////
    $day = "Sat";
        // 1. day > fri 
        // Have a nice Friday 

        // 2. day > sunday 
        // Have a happy weekend

        // 3. day ?
        // Have a good day
    if($day == "Fri"){
        echo "Have a nice Friday";
    } elseif($day == "Sunday"){
        echo "Have a happy weekend";
    } else 
        echo "Have a good day";

    /////////////////
    $day = "Friday";

    switch($day){
        case "Monday": 
            echo "Today is Monday, Special Dish Pasta";
        break;
        case "Monday": 
            echo "Today is Monday, Special Dish Pasta";
        break;
        case "Monday": 
            echo "Today is Monday, Special Dish Pasta";
        break;
        default: 
        echo "Day is not found!";
    }
?>