<?php
// For Loop
    // for($x=0; $x<10; $x++){
    //     echo "The numbers are". $x ."<br>";
    // }

    // $letters = [];
    // for($i='A'; $i != 'AA'; $i++){
    //     array_push($letters, $i);
    //     // echo $i."<br>";
    // }
    // $var = print_r($letters, true);
    // echo $var;
    // $numbers = [1, 2, 3];
    // array_push($numbers, 4, 5);
    // print_r($numbers);

/////////////////////////////////
// While Loop
/////////////////////////////////

$i=1;
//first check the condition 
while($i<=15)
{
	
	echo $i."<br>";
	$i++;
}

// Assignment with all loops types
// Output
// *  
// *  *  
// *  *  *  
// *  *  *  *  
// *  *  *  *  *  

// >>>> Year of birth using While Loop

////////////////////////
// do while loop
$i=1;
do

{
	echo $i."<br>";	
$i++;
}

while($i<=20);

?>