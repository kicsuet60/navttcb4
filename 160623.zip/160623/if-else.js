let hour = 22;
if(hour >= 6 && hour < 12){
    console.log('Good morning!');
} else if( 12 -- 18 ) {
    console.log('Good afternoon!');
} else {
    console.log('Good neight!');
}