const person = {
  name: "Ali",
  age: 21,
  role: "student",
};
//for in
// for (let key in person) {
//   // console.log(key);
//   console.log(key, person[key]);
// }
//for of
const colors = ["red", "green", "blue"];
for (let color of colors) {
  console.log(color);
}

// exersise
// above example with for - in
