let role = "guest";

switch (role) {
  case "guest":
    console.log("Guest User");
    break;
  case "admin":
    console.log("Admin User");
    break;

  default:
    console.log("Unknown User");
}

// Assignment:
// 1. write this code with if condition
