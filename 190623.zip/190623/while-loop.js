// while loop
// let i = 0;
// while (i < 21) {
//   if (i % 2 !== 0) console.log("Odd: " + i);
//   i++;
// }

// do while
let i = 0;
do {
  if (i % 2 !== 0) console.log("Odd: " + i);
  i++;
} while (i <= 5);
