// i want to write this 100000:? time
// console.log("message");
// console.log("message");
// console.log("message");
// console.log("message");
// console.log("message");
// console.log("message");
// console.log("message");
// console.log("message");

// for loop structure
// for(){

// }
for (let i = 0; i < 10; i++) {
  console.log("Hello Web", i);
}

// exercise for 2 minute
// start write "hello web 20 to 30"

// exercise 2 > find odd no between 0 - 20

// exercise 3 > for loop in reverse order
