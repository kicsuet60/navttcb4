<?php
$x = 10;
$y = 15;
$a = "10";
// var_dump($x == $a);
// var_dump($x === $a);
// var_dump($x != $y); // true
// var_dump($x < $y);
// var_dump($x <= $y); // true
// var_dump($x <= $y);
// var_dump($x > $y);
var_dump($x >= $a); //true
?>