<?php
$x = 2;
echo($x . "<br>");
$x = 5;
$x+=10;
echo($x . "<br>"); // 15
$x = 20;
$x -= 10;
echo($x . "<br>"); // 10
?>