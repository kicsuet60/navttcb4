<?php
    $x = "php";
    $y = " mysql";
    // echo $x . $y . "<br>";
    // echo $x .= $y . "<br>";
    echo $x . "<br>";

?>