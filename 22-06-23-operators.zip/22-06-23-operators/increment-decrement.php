<?php
// preincrement
    $x = 5;
    // echo ++$x . '<br>';
    // echo $x . '<br>'; //6
    
    //postincrement
    $x = 3;
    echo $x++ . '<br>';
    echo $x . '<br>'; //

    // predecrement
    // $x = 4;
    // echo --$x . '<br>';
    // echo $x . '<br>';

    // post decrement
    // $x = 6;
    // echo $x-- . '<br>';
    // echo $x . '<br>';
?>