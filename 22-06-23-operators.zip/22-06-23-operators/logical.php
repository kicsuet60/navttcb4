<?php
$x = true && true;
var_dump($x); // true
$y = false || true;
var_dump($y); // true
$z = !false;
var_dump($z); // true
?>