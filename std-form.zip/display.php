<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Form - GET</h1>
    <a href="std-form.html">Back to Form Page</a><br>
    <?php
    //  if($_GET['user_name'] && $_GET['user_name'] != '') {
    //     $name = $_GET['user_name'];
    //     $email = $_GET['input_email'];

    //     echo "Name: $name and Email: $email";
    //  } else {
    //     echo "Please submit again.";
    //  }       
    //////////////////////////////////////
       if(!empty($_GET['user_name']) ? $_GET['user_name'] : '') {
        $name = $_GET['user_name'];
        $email = $_GET['input_email'];

        echo "Name: $name and Email: $email";
     } else {
        echo "Please submit again.";
     }
    ?>
</body>
</html>