// let x = 10;
// let y = 20;
// // console.log(x + y);
// // console.log(x - y);
// // console.log(x * y);
// // console.log(x / y);
// // console.log(x % y);
// // console.log(x ** y);
// console.log(x++);
// console.log(x);
// console.log(x--);
// console.log(x);
///////////////////////////////////////////
// Assignment
// let x = 10;

// x = x + 5;
// x += 5;

// x = x * 5;
// x *= 5;

//////////////////////////////////////////////
// Comparison
// let x = 1;

// //Relational
// // console.log(1 > 0);
// // console.log(x >= 1);
// // console.log(x < 1);
// // console.log(x <= 1);

// //Equality
// console.log(x === 1);
// console.log("1" === 1);

////////////////////////////

let points = 60;
let type = points > 90 ? "Gold" : "Silver";
console.log(type);
