// console.log(true && true);
// console.log(false && false);
// let heighScore = true;
// let graduation = true;
// let eigiblForAdmition = heighScore && graduation;
// console.log(eigiblForAdmition);

// false || 1; //
console.log(false || "Anas");
console.log(false || 1);
