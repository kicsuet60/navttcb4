<?php


abstract class Car{
    abstract protected function brand($brand);
}
class Car1 extends Car{
    function brand($brand){
        return "My Car name is $brand!";
    }
}
$audi = new Car1();
echo $audi->brand("Audi");
?>
