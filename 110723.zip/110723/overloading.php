<!-- Method overloading is a concept that allows you to have a method that can perform differently based on its number of parameters. It allows you have multiple definitions for a same method in the same class.   -->

<?php
// function add(int $a, int $b):int{
//     return $a + $b;
// }

// function add(int $a, int $b, int $c): int
// {
// 	$sum = $a + $b + $c;
// 	return $sum > 10 ? 10 : $sum;
// }
//  echo add(25,2,2);

///////////////////////////////////
class SampleClass
{
	function __call($function_name, $arguments)
	{
		$count = count($arguments); //3

		// Check function name
		if ($function_name == 'add') {
			if ($count == 2) {
				return array_sum($arguments);
			} else if (3 == 3) {
				return array_sum($arguments) > 10 ? 10 : array_sum($arguments);
			}
		}
	}
}
$sampleObject = new SampleClass;
//echo $sampleObject->add(12, 12) . PHP_EOL; // Outputs 24 
echo $sampleObject->add(18, 2, 5) . PHP_EOL; // Outputs 10

// __call() – triggered while invoking overloaded methods in the object context.
?>
