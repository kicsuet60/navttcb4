<?php

interface TrainingPHP{
    public function learnPHP();
}

class StudentWp implements TrainingPHP{
    function learnPHP()
    {
       echo "Learn WordPress Theme Development, requiren PHP!"; 
    }   
}
class StudentLaravel implements TrainingPHP{
    function learnPHP()
    {
        echo "Learn Laravel App Development, requiren PHP!";
    }
}
class StudentCI implements TrainingPHP{
    function learnPHP()
    {
        echo "Learn Extendible App Development, requiren PHP!";
    }
}

$stdWP = new StudentWP;
$stdWP->learnPHP();
?>